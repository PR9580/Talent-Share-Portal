export const environment = {

    production: true,

    menteeUrl: 'http://172.16.238.168:8090',
    mentorUrl:'http://172.16.238.168:8070'

  };
