export const environment = {

    production: false,

    menteeUrl: 'http://localhost:8090',
    mentorUrl:'http://localhost:8070'

  };
