export class Skill {
    skillId: number;
    skill: string;
  
    constructor(skillId: number, skill: string) {
      this.skillId = skillId;
      this.skill = skill;
    }
  }
  