export class Category {

    categoryId: number=0;
    category: string='';
}