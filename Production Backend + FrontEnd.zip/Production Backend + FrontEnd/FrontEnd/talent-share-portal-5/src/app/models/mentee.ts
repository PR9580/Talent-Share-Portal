export class Mentee{
    employeeId !:number;
    firstName !:string;
    lastName !:string;
    email !:string;
    password !: string;
}
