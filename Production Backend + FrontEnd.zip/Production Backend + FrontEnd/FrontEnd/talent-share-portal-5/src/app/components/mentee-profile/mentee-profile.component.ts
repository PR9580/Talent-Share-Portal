import { Component } from '@angular/core';

@Component({
  selector: 'app-mentee-profile',
  templateUrl: './mentee-profile.component.html',
  styleUrls: ['./mentee-profile.component.css']
})
export class MenteeProfileComponent {

}
