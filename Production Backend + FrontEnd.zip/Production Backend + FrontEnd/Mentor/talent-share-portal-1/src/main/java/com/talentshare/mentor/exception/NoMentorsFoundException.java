package com.talentshare.mentor.exception;

public class NoMentorsFoundException extends RuntimeException{
	
	public NoMentorsFoundException(String message) {
		super(message);
	}

}
